THIS TOOL IS UNOFFICIAL AND FOR EXPERT ONLY !

READ THE PDF DOCUMENTATION TO KNOW HOW TO USE IT !

Command to launch the tool :
execVM "R3F_LOG\addons_config\logistics_config_maker_tool\launch_config_tool.sqf";

Don't forget to fill the list of class names to configure in list_of_objects_to_config.sqf.